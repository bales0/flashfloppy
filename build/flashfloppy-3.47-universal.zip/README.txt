FlashFloppy Universal 3.47 — FDD / QuickDisk / Apple II / Update FW
Build: 2026-10-28; includes upstream bug fixes and the OLED/menu update.

MAIN USB UPDATE (Universal includes all three emulations)
  FF_Gotek-3.47.upd       STM32F105, legacy bootloader format
  flashfloppy-3.47.upd    modern format, STM32F105 + AT32F435
Copy only ONE chosen .upd to the USB drive during an update.

bootloader/   Bootloader updater .upd; raw bootloader/updater files by MCU.
              Use only when updating the bootloader, then replace its .upd
              with the Universal application .upd.
firmware/     Universal BIN / combined HEX / combined DFU, named by MCU.
              HEX/DFU include the matching bootloader. BIN is application only.
alt/          Standalone FDD/QD/Apple, debug/logfile, IO test and special Apple
              bootloader; every variant is labelled. Not needed for normal use.
examples/     Original generic FF.CFG / IMG.CFG, host presets and test images.
FF.CFG        Sharp MZ-800 preset: fdd-interface=shugart; oled-contrast=6.
IMG.CFG       Generic image-geometry example, optional; adjust before use.

OLED Contrast uses 1..10 in Main Menu and FF.CFG; default 6. Update old CFG values.
Configure FF OSD is hidden unless an external module is detected.

examples/images contains original user-supplied test files, copied unchanged.
They are NOT guaranteed blank disks. Work on copies for write/format tests.
Physical QD is read/write; logical QD/MZQ/QDF are read-only.
Apple II supports HFE/NIB/NIC/DSK/DO/PO read/write. Electrical hardware tests
remain unperformed. Firmware version is 3.47; source changes are uncommitted.

Build logs and detailed audit remain outside this clean directory:
  out/audit-347-oled-20261028/
  docs/universal-347-upstream-bugfixes-2026-10.md
SHA256SUMS lists every delivered file except this checksum list itself.
