FlashFloppy 3.46 Universal: FDD + QuickDisk + Apple II, complete build.

Hold SELECT at power-on, release, select QuickDisk / FDD / Apple II / Update FW.
Apple II shares the FDD core and supports HFE only. fdd-* and qd-* interface
settings do not configure Apple. Global settings and step-volume still apply.
STM32F105 app: 95756 B, 500 B free. Static RAM allocation unchanged.
See universal-apple2-validation.md for current sizes, tests and hardware caveats.
universal-settings-validation.md records the earlier Task 2 baseline.
Apple electrical read/write/step timing still requires testing on hardware.
QFN32: Apple phase PA10 replaces encoder SELECT; use SELECT on PA5 if present.
PA9 is a phase, not JC. Install this new bootloader too for saved-mode handling.
LEFT+RIGHT at power-on remains recovery update.


STM32F105 USB files:
  Firmware: alt/dual/FF_Gotek-dual-3.46.upd
  Bootloader updater: alt/bootloader/FF_Gotek-bootloader-3.46.upd
Modern update catalogs in the same folders support STM32F105 and AT32F435.
For each update, put only its chosen .upd on the USB drive.

To install both, update the bootloader first, then install the dual firmware.
The bootloader updater erases its own application after success. Replace the
USB update file with the dual firmware and restart; the bootloader will load it.

Logical legacy .qd, .mzq and all .qdf images are read-only. They cannot be
formatted or written, even with write-protect=no. The display shows * as soon
as the image is mounted. Native physical .qd retains its working write path.
FDD interface options now use fdd-* names; legacy unprefixed names are ignored.
QD READY: qd-ready = auto | standard | motor-off | jc; independent of FDD.
Auto: sharp/roland=motor-off, akai/generic=standard. Explicit modes override host.
Sharp preset: fdd-interface=shugart, qd-host=sharp, qd-ready=auto.
FDD/Apple STEP volume: step-volume. Independent QD motor: qd-motor-volume.
Remove USB, briefly press/release SELECT: Main Menu lists all eight runtime
settings. Changes are RAM-only until reset; no Settings in Eject Menu.
QD percentages are removed. R indicates the READY read stream; W only
during accepted physical WGATE, never USB writeback alone. OLED/LCD shows
* for every read-only image, also alongside R. Seven-segment: rd/wrt/qd.
See universal-settings-validation.md for build sizes and hardware checklist.

variants/ contains every supported production, debug and logfile build,
including bootloaders and the special STM32F105 Apple2 bootloader.
Combined debug/logfile dual builds are available for AT32F435 only, following
the existing STM32F105 flash-size limitation.

All image read/protection tests, MCU dispatcher tests, flash checks, linked
engine/HEX checks, bootloader payload checks and update CRC verification passed.
